import { Component, OnInit } from '@angular/core';

// Importaciones
import { ChartType } from 'chart.js';
import { MultiDataSet, Label } from 'ng2-charts';

@Component({
  selector: 'app-my-doughnut-chart',
  templateUrl: './my-doughnut-chart.component.html',
  styleUrls: ['./my-doughnut-chart.component.css']
})
export class MyDoughnutChartComponent implements OnInit {

 

  // Doughnut
  public doughnutChartLabels: Label[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData: MultiDataSet = [
    [550, 450, 100],
  ];
  // El tipo de gráfico que queremos mostrar
  public doughnutChartType: ChartType = 'doughnut';

  // Colores
  public chartColors: Array<any> = [
    { // all colors in order
      backgroundColor: ['#004C99', '#0080FF', '#66B2FF']
    }
  ];
  constructor() { }

  ngOnInit() {
  }

  // events
  public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }
}
