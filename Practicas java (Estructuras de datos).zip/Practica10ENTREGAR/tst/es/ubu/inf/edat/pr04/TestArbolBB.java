package es.ubu.inf.edat.pr04;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import es.ubu.inf.edat.pr04.ArbolBB;

public class TestArbolBB {

	ArbolBB<Integer> arbol;
	List<Integer> datos;

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
		arbol.clear();
	}

	@Test
	public void testAdd_NoRepetidos() {

		datos = Arrays.asList(375, 450, 400, 350);

		arbol = new ArbolBB<Integer>(datos);
		assertEquals(4, arbol.size());

		datos = Arrays.asList(375, 450, 400, 350, 300, 90, 125);

		arbol = new ArbolBB<Integer>(datos);
		assertEquals(7, arbol.size());

	}

	@Test
	public void testAdd_Repetidos() {

		datos = Arrays.asList(375, 450, 400, 350);

		arbol = new ArbolBB<Integer>(datos);
		assertEquals(4, arbol.size());

		datos = Arrays.asList(375, 450, 400, 350, 375, 450, 400, 350);
		arbol = new ArbolBB<Integer>(datos);

		assertEquals(4, arbol.size());

	}

	@Test
	public void testIterator() {

		testAdd_NoRepetidos();

		datos = Arrays.asList(375, 450, 400, 350, 300, 90, 125);
		Collections.sort(datos);

		Iterator<Integer> it = arbol.iterator();

		int i = 0;
		while (it.hasNext()) {
			assertEquals(it.next(), datos.get(i));
			i++;
		}

		assertEquals(datos.size(), i);

	}

	@Test
	public void testBorradoHoja() {

		testAdd_NoRepetidos();

		datos = new ArrayList<Integer>(Arrays.asList(375, 450, 400, 350, 300, 90, 125, 360, 500));
		arbol.add(360);
		arbol.add(500);

		assertTrue(arbol.containsAll(datos));

		arbol.remove(125);
		datos.remove(new Integer(125));
		assertEquals(8, arbol.size());
		assertTrue(arbol.containsAll(datos));

	}

	@Test
	public void testBorradoSolo1Hijo() {

		testAdd_NoRepetidos();

		datos = new ArrayList<Integer>(Arrays.asList(375, 450, 400, 350, 300, 90, 125, 360, 500));
		arbol.add(360);
		arbol.add(500);

		assertTrue(arbol.containsAll(datos));

		arbol.remove(90);
		datos.remove(new Integer(90));
		assertEquals(8, arbol.size());
		assertTrue(arbol.containsAll(datos));

	}

	@Test
	public void testBorrado2Hijos() {

		testAdd_NoRepetidos();
		arbol.add(360);
		arbol.add(500);

		datos = new ArrayList<Integer>(Arrays.asList(375, 450, 400, 350, 300, 90, 125, 360, 500));

		assertTrue(arbol.containsAll(datos));
		arbol.remove(350);
		datos.remove(new Integer(350));

		assertEquals(8, arbol.size());
		//List<E> rellenarIterador = arbol.rellenarIterador();
		//System.out.println(it);
		assertTrue(arbol.containsAll(datos));

		arbol.remove(450);
		datos.remove(new Integer(450));

		assertEquals(7, arbol.size());
		assertTrue(arbol.containsAll(datos));
	}

	/**
	 * TEST DE SAMUEL CASAL CANTERO
	 */

	@Test
	public void testSCCBorrarArbolVacio() {
		arbol = new ArbolBB<Integer>();
		assertFalse(arbol.remove(1234658));
	}

	@Test
	public void testSCCBorrarElementoInexistente() {
		testAdd_NoRepetidos();
		assertFalse(arbol.remove(1234658));
	}

	@Test
	public void testSCCControlHoja() {
		testAdd_NoRepetidos();
		arbol.add((Integer) 9999);
		assertFalse(arbol.add(9999));
		assertFalse(arbol.remove((Integer) 10000));
	}

	@Test
	public void testSCCRaizHoja() {
		List lista = new ArrayList<Integer>();
		lista.add(1);
		arbol = new ArbolBB<Integer>(lista);
		assertTrue(1 == arbol.size());
		// System.out.println("Tam antes de borrado =" + arbol.size());
		arbol.remove(1);
		// System.out.println("Tam borrado =" + arbol.size());
		assertTrue(0 == arbol.size());
	}

	@Test
	public void testSCCBorradoRaizUnHijoDerecho() {
		List lista = new ArrayList<Integer>();
		lista.add(50);
		lista.add(65);
		arbol = new ArbolBB<Integer>(lista);
		arbol.remove(50);
		assertTrue(1 == arbol.size());
	}

	@Test
	public void testSCCBorradoNodUnHijoDer() {
		datos = new ArrayList<Integer>(Arrays.asList(50, 75, 76, 70, 80));
		arbol = new ArbolBB<Integer>(datos);

		arbol.remove(76);
		// System.out.println(arbol.size());
		assertTrue(4 == arbol.size());
		datos.remove(2);
		assertTrue(arbol.containsAll(datos));
	}

	@Test
	public void testSCCBorradoNodUnHijoIzq() {
		datos = new ArrayList<Integer>(Arrays.asList(80, 40, 30, 15, 20));
		arbol = new ArbolBB<Integer>(datos);

		arbol.remove(40);
		assertTrue(4 == arbol.size());
		datos.remove(1);
		assertTrue(arbol.containsAll(datos));
	}

	@Test
	public void testSCCBorradoDosHijos() {
		datos = new ArrayList<Integer>(Arrays.asList(80, 40, 30, 15, 20));
		arbol = new ArbolBB<Integer>(datos);

		arbol.remove(30);
		assertTrue(4 == arbol.size());
		datos.remove(2);
		assertTrue(arbol.containsAll(datos));
	}

	@Test
	public void testSCCBorradoDosHijosNODORAIZ() {
		datos = new ArrayList<Integer>(Arrays.asList(10, 20, 4));
		arbol = new ArbolBB<Integer>(datos);

		arbol.remove(10);
		assertTrue(2 == arbol.size());
		datos.remove(0);
		assertTrue(arbol.containsAll(datos));
	}

	@Test
	public void testSCCProfundidad() {

		// Controlamos la profundidad de un nodo hoja
		datos = new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
		arbol = new ArbolBB<Integer>(datos);

		assertTrue(9 == arbol.size());
		assertTrue(8 == arbol.profundidad(9));

		// Control del nodo raiz
		datos = new ArrayList<Integer>(Arrays.asList(1));
		arbol = new ArbolBB<Integer>(datos);

		assertTrue(1 == arbol.size());
		assertTrue(0 == arbol.profundidad(1));

		// Control del nodo que no existe en la estructura
		assertTrue(-1 == arbol.profundidad(100));

		// Control de profundidad cuando la estructura esta vacia
		arbol.clear();
		assertTrue(-1 == arbol.profundidad(100));
	}

	@Test
	public void testSCCAltura() {

		// Controlamos la profundidad de un nodo hoja
		datos = new ArrayList<Integer>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
		arbol = new ArbolBB<Integer>(datos);

		// Controlamos la altura de uno de los elementos intermedios
		assertTrue(9 == arbol.size());
		//System.out.println(arbol.altura(6));
		assertTrue(3 == arbol.altura(6));

		// Cotrolamos la altura de el nodo raiz
		assertTrue(8 == arbol.altura(1));
		// Controlamos la altura del nodo hoja 9
		assertTrue(0 == arbol.altura(9));

		// Control del nodo que no existe en la estructura
		assertTrue(-1 == arbol.altura(100));

		// Control de profundidad cuando la estructura esta vacia
		arbol.clear();
		assertTrue(-1 == arbol.altura(100));

	}

}
