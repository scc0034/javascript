package es.ubu.inf.edat.pr11;

import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import es.ubu.inf.edat.datos.GeneradorEnteros;
import es.ubu.inf.edat.pr05.ArbolBBSortedSet;

public class ArbolBBSortedSetTest {

	SortedSet<Integer> control;
	ArbolBBSortedSet<Integer> arbol;

	@Before
	public void setUp() throws Exception {
		control = new TreeSet<>();
		arbol = new ArbolBBSortedSet<>();
	}

	@After
	public void tearDown() throws Exception {
		control.clear();
		arbol.clear();
	}

	@Test
	public void testArbolBBSortedSet() {
		arbol = new ArbolBBSortedSet<>();
	}

	@Test
	public void testComparator() {

		assertNull(arbol.comparator());
		
		ArbolBBSortedSet<Character> arbol2 = 
				new ArbolBBSortedSet<Character>(Comparator.reverseOrder());
	
		Comparator<Character> comp = (Comparator<Character>) arbol2.comparator();
		assertNotNull(comp);

	}

	@Test
	public void testFirst() {

		for(int i = 0; i<10; i++) {

			List<Integer> aleatorios = GeneradorEnteros.listaAleatoriaUnicos(25);

			control.addAll(aleatorios);
			arbol.addAll(aleatorios);

			assertEquals(control.size(), arbol.size());
			assertEquals(control.first(), arbol.first());

		}

	}

	@Test
	public void testHeadSet_contenido() {

		List<Integer> aleatorios = GeneradorEnteros.listaAleatoriaUnicos(25);

		control.addAll(aleatorios);
		arbol.addAll(aleatorios);

		arbol.containsAll(control);

		assertEquals(control.size(), arbol.size());

		for(int i = 0; i<10; i++) {
			

			Integer buscado = aleatorios.get((int) Math.random() * 25);
			
			assertEquals(arbol.headSet(buscado).getClass(), ArbolBBSortedSet.class);
			assertEquals(control.headSet(buscado), arbol.headSet(buscado));

		}

	}

	@Test
	public void testLast() {

		for(int i = 0; i<10; i++) {

			List<Integer> aleatorios = GeneradorEnteros.listaAleatoriaUnicos(25);

			control.addAll(aleatorios);
			arbol.addAll(aleatorios);

			assertEquals(control.size(), arbol.size());
			assertEquals(control.last(), arbol.last());

		}
	}

	@Test
	public void testSubSet_contenidos() {
		
		List<Integer> aleatorios = GeneradorEnteros.listaAleatoriaUnicos(25);

		control.addAll(aleatorios);
		arbol.addAll(aleatorios);

		arbol.containsAll(control);

		assertEquals(control.size(), arbol.size());

		for(int i = 0; i<10; i++) {

			Integer desde = aleatorios.get((int) Math.random() * 25);
			Integer hasta = aleatorios.get((int) Math.random() * 25);
			
			if(desde>hasta)
				continue;
			
			
			assertEquals(arbol.subSet(desde,hasta).getClass(), ArbolBBSortedSet.class);
			assertEquals(control.subSet(desde,hasta), arbol.subSet(desde,hasta));

		}

	}

	@Test
	public void testTailSet_contenido() {

		List<Integer> aleatorios = GeneradorEnteros.listaAleatoriaUnicos(25);

		control.addAll(aleatorios);
		arbol.addAll(aleatorios);

		arbol.containsAll(control);

		assertEquals(control.size(), arbol.size());

		for(int i = 0; i<10; i++) {

			Integer buscado = aleatorios.get((int) Math.random() * 25);
			assertEquals(arbol.tailSet(buscado).getClass(), ArbolBBSortedSet.class);
			assertEquals(control.tailSet(buscado), arbol.tailSet(buscado));

		}
	}
	
	@Test
	public void testReconstruyeArbol() {
		
		List<Integer> preorder = Arrays.asList(5,4,22,15,11,17,30,42);
		List<Integer> inorder = Arrays.asList(4,5,11,15,17,22,30,42);
		
		arbol.reconstruyeArbol(preorder,inorder);
		
		assertEquals(inorder.size(), arbol.size());
		
		Iterator<Integer> contIt = inorder.iterator();
		Iterator<Integer> arbolIt = arbol.iterator();
		
		while (contIt.hasNext()) {
			assertEquals(contIt.next(),arbolIt.next());
		}
		
		assertEquals(3,arbol.altura(5));
		assertEquals(1,arbol.altura(15));
		assertEquals(0,arbol.altura(42));
		assertEquals(0,arbol.altura(4));
		
	}
	
	public void testProfundidad() {
		
		List<Integer> insertar = Arrays.asList(5,4,22,15,30,11,17,42);
		arbol.addAll(insertar);

		assertEquals(0,arbol.profundidad(5));
		assertEquals(2,arbol.profundidad(15));
		assertEquals(3,arbol.profundidad(42));
		assertEquals(1,arbol.profundidad(4));

	}
	
	
}
