package es.ubu.inf.edat.pr05;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import es.ubu.inf.edat.pr05.ArbolBB;

/**
 * Clase {@link ArbolBB} Clase para implentar el �rbol de b�squeda binaria de
 * los datos repartidos en nodos, de la clase de pr�cticas de la asignatura
 * Estructuras de Datos de la Universidad de Burgos
 * 
 * @author Samuel Casal Cantero
 * @version 7/05/2019
 *
 * @param <E> Indica la genericidad de la clase para que trate con cualquier
 *        tipo de objetos.
 */
public class ArbolBB<E> extends AbstractSet<E> {

	/**
	 * Clase {@link NodoArbol}
	 * 
	 * Sirve para construir toda la estructura del �rbol.
	 */
	protected class NodoArbol<E> {

		// Atributos de la clase NodoArbol
		private E elemento; // Objeto que guardamos,son los datos
		private NodoArbol<E> nodDer;
		private NodoArbol<E> nodIzq;
		private NodoArbol<E> nodPadre;

		// Constructor de la clase nodo
		public NodoArbol(E e) {
			if (e == null) {
				throw new NullPointerException("Contenido del nodo no puede ser null");
			}
			this.elemento = e;
			// Cuando creamos un nodo debemos de tener los nodos der e izq como nulos
			this.nodDer = null;
			this.nodIzq = null;
			// this.nodPadre = null;
		}

		// Constructor vacio
		public NodoArbol() {

		}

		/**
		 * NUEVO CONSTRUCTO PARA LA PRACTICA SORTED SET Constructor de completo que nos
		 * deja controlar todos los elementos
		 * 
		 * @param e        elemento
		 * @param nodDer   NodoArbol
		 * @param nodIzq   NodoArbol
		 * @param nodPadre NodoArbol
		 */
		public NodoArbol(E e, NodoArbol<E> nodDer, NodoArbol<E> nodIzq, NodoArbol<E> nodPadre) {

			this.elemento = e;
			// Cuando creamos un nodo debemos de tener los nodos der e izq como nulos
			this.nodDer = nodDer;
			this.nodIzq = nodIzq;
			this.nodPadre = nodPadre;
		}

		/**
		 * M�TODOS GET DE LA CLASE NodoArbol
		 */
		public E getElemento() {
			return this.elemento;
		}

		public NodoArbol<E> getNodoDerecha() {
			return this.nodDer;
		}

		public NodoArbol<E> getNodoIzquierda() {
			return this.nodIzq;
		}

		public NodoArbol<E> getPadre() {
			return this.nodPadre;
		}

		/**
		 * M�TODOS SET DE LA CLASE NodoArbol
		 */
		public void setElemento(E e) {
			this.elemento = e;
		}

		public void setNodoDer(NodoArbol<E> nodo) {
			this.nodDer = nodo;
		}

		public void setNodoIzq(NodoArbol<E> nodo) {
			this.nodIzq = nodo;
		}

		public void setPadre(NodoArbol<E> nodo) {
			this.nodPadre = nodo;
		}
	}// Final de la clase NodoArbol

	// Atributos de la clase ArbolBB
	protected NodoArbol<E> nodoRaiz = null;
	protected int size = 0;
	protected Comparator<? super E> comparador = null;

	/**
	 * Constructores de la clase ArbolBB Tenemos que tener 4 formas diferentes de
	 * hacerlos: 1- Constructor Vacio 2- Constructor con un comparator 3-
	 * Constructor que reciba una colecction 4- Constructor que recibe una clase que
	 * implementa comparator
	 */
	// Constructor vacio
	public ArbolBB() {
		this.nodoRaiz = null;
	}

	// Constructor con comparador
	public ArbolBB(Comparator<? super E> comparador) {
		this.nodoRaiz = null;
		this.comparador = comparador;
	}

	// Constructor con coleccion de datos
	public ArbolBB(Collection<E> conjuntoElementos) {
		for (E e : conjuntoElementos) {
			this.add(e);
		}
	}

	// Constructor para comparador + datos
	public ArbolBB(Collection<E> conjuntoElementos, Comparator<? super E> comparador) {
		this.comparador = comparador;
		for (E e : conjuntoElementos) {
			this.add(e);
		}
	}

	/**
	 * M�tood add
	 * 
	 * Este m�todo se encarga de a�adir nodos en el �rbol, por lo que tenemos que
	 * controlar que el nodo no se encuentra ya en el �rbol, y si no se encuentra
	 * a�adirlo.
	 * 
	 * Tenemos que devolver el valor true para el caso de que inserte en la
	 * estructura y false para el caso de que no
	 */
	@Override
	public boolean add(E e) {

		// Creamos el nodo para a�adir en la estructura
		NodoArbol<E> nuevoNodo = new NodoArbol<E>(e);

		// si raiz == null es porque no tenemos nodo raiz
		if (this.nodoRaiz == null) {
			// Cambiamos el valor de raiz y size++
			this.nodoRaiz = nuevoNodo;
			nuevoNodo.setPadre(null);
			size++;
			return true;
		} else {
			// Recogemos el nodo de control
			NodoArbol<E> nControl = controlNodo(e);

			// Control de nControl con el elemento, si son igules es que esta
			if (comparar(nControl.getElemento(), e) != 0) {

				// Insertamos el nodo dependiendo de si el padre es menor o no
				if (comparar(e, nControl.getElemento()) > 0) {
					// System.out.println("colocamos " + e + " a la derecha de " +
					// nControl.getElemento().toString());
					nControl.setNodoDer(nuevoNodo);
				} else {
					// System.out.println("colocamos " + e + " a la izquierda de " +
					// nControl.getElemento().toString());
					nControl.setNodoIzq(nuevoNodo);
				}
				nuevoNodo.setPadre(nControl);
				size++;
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean remove(Object o) {
		// Controlamos que tenemos elementos dentro del arbol
		if (size == 0) {
			return false;
		}
		// Cambiamos el tipo de datos de O a E
		E eleBorrar = (E) o;

		// Miramos si tenemos el elemento en la estructura, ya que nodoControl es el
		// nodo que contiene el Elemento E e que vamos a borrar de la estructura

		NodoArbol<E> nodoControl = controlNodo(eleBorrar);
		// en el caso de que comparar == 0 es que tenemos el nodo que queremos borrar

		// Cogemos el nodo padre del nodo a borrar
		NodoArbol<E> nPadre = nodoControl.getPadre();
		/*
		 * Tenemos varios casos para borrar . 1 Que el nodo sea hoja 2. Que el nodo solo
		 * tenga un hijo. 3. Que el nodo tenga dos hijos
		 */

		/*
		 * Controlamos el nodoControl, si son distinto, es porque no esta el nodo que
		 * contiene el elemento que vamos a querer borrar
		 */
		if (!contains(eleBorrar)) {
			return false;
		} else {
			/* CONTROL DE NODO HOJA */
			if (nodoControl.getNodoIzquierda() == null && nodoControl.getNodoDerecha() == null) {

				// Puede que el nodo sea el raiz, en ese caso el padre es null
				/* NODO HOJA ES NODO RAIZ */
				if (nPadre == null) {
					this.clear();
				} else {
					/* NODO HOJA */
					// Miramos cual de los dos hijos del padre es el elemento a borrar y lo dejamos
					// a null
					if (comparar(eleBorrar, nPadre.getNodoDerecha().getElemento()) == 0) {
						nPadre.setNodoDer(null);
					} else {
						nPadre.setNodoIzq(null);
					}
					nodoControl.setPadre(null);
					size--;
				}
			} // Final del if de nodos hoja

			/* CONTROL DE NODOS CON SOLO UN HIJO */
			// En ese caso debemos de controlar que sustituimos
			if (nodoControl.getNodoIzquierda() == null && nodoControl.getNodoDerecha() != null) {
				// System.out.println("Nodo con hijo derecho");

				// Cogemos el nodo hijo
				NodoArbol<E> nHijoDer = nodoControl.getNodoDerecha();
				// Caso de que el nodo raiz es el elemento a borar con un solo hijo
				if (nPadre == null) {
					nodoControl.setPadre(null);
					this.nodoRaiz = nodoControl;
				} else {
					// Controlamos de que rama del padre cuelga el nodo control y cambiamos el nodo
					// hijo por su nuevo hijo
					if (comparar(eleBorrar, nPadre.getElemento()) > 0) {
						nPadre.setNodoDer(nHijoDer);
					} else {
						nPadre.setNodoIzq(nHijoDer);
					}
					// Nodo que tenemos que borrar dejamos el padre a null y el hijoDer
					nodoControl.setPadre(null);
					nodoControl.setNodoDer(null);

					// Al nodo hijo lo definimos el padre nuevo
					nHijoDer.setPadre(nPadre);
				}

				size--;
			} // Fin control 1 hijo der

			if (nodoControl.getNodoIzquierda() != null && nodoControl.getNodoDerecha() == null) {
				// System.out.println("Nodo con hijo izquierdo");
				// Cogemos el nodo hijo
				NodoArbol<E> nHijoIzq = nodoControl.getNodoIzquierda();
				// Caso de que el nodo raiz es el elemento a borar con un solo hijo
				if (nPadre == null) {
					// System.out.println("Borrando NODO RAIZ 1 HIJO IZQ");
					nodoControl.setPadre(null);
					this.nodoRaiz = nodoControl;
				} else {
					// Mostramos el mensaje de que tenemos un hijo del elemento que queremos borrar
					// System.out.println("Borrando NODO CON 1 HIJO IZQ ");

					// Controlamos de que rama del padre cuelga el nodo control y cambiamos el nodo
					// hijo por su nuevo hijo
					if (comparar(eleBorrar, nPadre.getElemento()) > 0) {
						nPadre.setNodoDer(nHijoIzq);
					} else {
						nPadre.setNodoIzq(nHijoIzq);
					}
					// El nodoControl lo dejamos a null porque es l que vamos a borrar
					nodoControl.setPadre(null);
					nodoControl.setNodoIzq(null);

					// El hijo del nodo control tiene el nuevo padre que es el padre de control
					nHijoIzq.setPadre(nPadre);
				}
				size--;
			} // Fin de control 1 hijo izq

			/*
			 * CONTROL DE LOS NODOS QUE TIENEN 2 HIJOS
			 */
			if (nodoControl.getNodoIzquierda() != null && nodoControl.getNodoDerecha() != null) {
				// Declaramos el nodo del intercambio
				NodoArbol<E> nodoHojaCambiar;

				// Generamos n�meros decimales entre 0 y 1
				Double numAl = Math.random();

				if (numAl < 0.50) {
					//System.out.println("Camino de la derecha");
					nodoHojaCambiar = menorNodo(nodoControl.getNodoDerecha());
					// Quitamos el nodo de la estructura
					nodoHojaCambiar.getPadre().setNodoDer(null);
				} else {
					//System.out.println("Camino de la izqyierda");
					nodoHojaCambiar = mayorNodo(nodoControl.getNodoIzquierda());
					// Dejamos de apuntar a ese nodo para borrarlo
					nodoHojaCambiar.getPadre().setNodoIzq(null);
				}

				// Nos quedamos con el dato del nodo a cambiar
				E elementoAux = nodoHojaCambiar.getElemento();

				// Cambiamos el valor del dato del nodo que borramos
				nodoHojaCambiar.setElemento(nodoControl.getElemento());
				nodoHojaCambiar.setElemento(null);
				nodoControl.setElemento(elementoAux);

				// En el caso de que el nodo mayor o menor tenga hijos
				if (nodoHojaCambiar.getNodoDerecha() != null) {
					nodoControl.setNodoDer(nodoHojaCambiar.getNodoDerecha());
				}

				if (nodoHojaCambiar.getNodoIzquierda() != null) {
					nodoControl.setNodoIzq(nodoHojaCambiar.getNodoIzquierda());
				}
				// Cambiamos el tama�o de la estructura
				size--;
			}
			return true;
		}
	}

	/**
	 * M�todo clear Limpiar el contenido del ArbolBB, dejando el n�mero de
	 * elementos< a 0 y el nodo raiz a null, por lo que al deslocalizar el nodo raiz
	 * todos los dem�s nodos pasan a un estado de inv�lido
	 */
	public void clear() {
		// Dejamos el raiz a null y el tam a 0
		this.nodoRaiz = null;
		this.size = 0;
	}

	/**
	 * M�todo controlNodo
	 * 
	 * @param e, es el elemento que queremos buscar en el arbol, nos devuelve el
	 *        nodo que contiene el elemento o el nodo hoja donde debemos insertar
	 * 
	 * @return nodo que contiene el elemento, o el nodo hoja
	 */
	public NodoArbol<E> controlNodo(E e) {
		// Declaraci�n de las variables
		NodoArbol<E> nDevolver = null;
		NodoArbol<E> nActual = null, nPadre = null;

		// Partimos desde el nodo raiz
		nActual = nodoRaiz;

		/* BUCLE DE CONTROL */
		/*
		 * Controlamos que el nActual no sea nulo, porque entonces es hoja Controlamos
		 * que los elementos no sean iguales, porque entonces el nodo esta
		 */
		while (nActual != null) {
			nPadre = nActual;
			if (comparar(e, nActual.getElemento()) < 0) {
				nActual = nActual.getNodoIzquierda();
			} else if (comparar(e, nActual.getElemento()) > 0) {
				nActual = nActual.getNodoDerecha();
			} else if (comparar(e, nActual.getElemento()) == 0) {
				return nActual;
			}
		}
		nDevolver = nPadre;
		return nDevolver;
	}

	/**
	 * M�todo comparar Sirve para comparar dos elementos que se les pasa como
	 * par�metro
	 * 
	 * @param e1
	 * @param e2
	 * @return Resultado de la comparacion de los dos elementos de la lista
	 */
	@SuppressWarnings("unchecked")
	public int comparar(E e1, E e2) throws ClassCastException {
		// En el caso de que no tengamos comparador
		if (this.comparador == null) {
			// System.out.println("COMPARANDO A)"+e1+ " B)"+e2);
			// System.out.println(((Comparable<E>) e1).compareTo(e2));
			return ((Comparable<E>) e1).compareTo(e2);
		} else {
			return comparador.compare(e1, e2);
		}
	}

	@Override
	/**
	 * 
	 * M�todo Iterador Nos devuelve un iterador del ArbolBB, para ello necesitamos
	 * crear la lista que contiene todos los elementos del mismo. De esto se encarga
	 * el m�todo rellenar iterador.
	 * 
	 * @return Iterador de la estructura del arbol en inOrden
	 */
	public Iterator<E> iterator() {
		// Declaramos las variables
		List<E> listaInOrden = new ArrayList<E>();

		// A�adimos los elementos a la lista por el m�todo inOrden
		listaInOrden = rellenarIterador(nodoRaiz, listaInOrden);

		return listaInOrden.iterator();
	}

	/**
	 * M�todo rellenar Iterador. Este m�todo nos rellena la lista de manera in orden
	 * recursivo. De tal manera que recorremos en profundidad el arbol, siempre
	 * empezando por la izquierda, para tener los elementos ordenados de menor a
	 * mayor.
	 * 
	 * @param nodoInicio   Nodo que contiene los hijos, por lo que tambien es el
	 *                     padre
	 * @param listaInOrden lista que vamos a devolver, pero que ncesitamos pasar
	 *                     como parametro
	 * 
	 * @return devuelve listaInOrden, ya que la vamos pasando y se va rellenando
	 */
	public List<E> rellenarIterador(NodoArbol<E> nodoInicio, List<E> listaInOrden) {
		// En el caso de que no tengamos m�s hijos paramos devolvemos solo la lista
		if (nodoInicio != null) {
			// Recorremos el arbol por las ramas de la izquierda, hasta el final
			rellenarIterador(nodoInicio.getNodoIzquierda(), listaInOrden);
			// A�adimos el nodo a la lista
			listaInOrden.add(nodoInicio.getElemento());
			// Miramos si tiene nodos a la derecha
			rellenarIterador(nodoInicio.getNodoDerecha(), listaInOrden);
		}
		return listaInOrden;
	}

	@Override
	/**
	 * M�todo size Devuelve el n�mero de elementos que forman parte del �rbol
	 * 
	 * @return devuevlve el n�mero de elementos del arbol
	 */
	public int size() {
		return this.size;
	}

	/**
	 * M�todo profundidad. M�todo que nos dice a que profundidad se encuentra el
	 * nodo que contiene el dato e, que pasamos como par�metro. En el caso de que el
	 * elementos no se encuentre, la profundidad sera de -1
	 * 
	 * @param e, elemento del cual vamos a saber la profundidad
	 * @return int profundidad, posicion dentro del nodo en el arbol
	 */
	public int profundidad(E e) {

		// Declaracion de variables
		int profundidad = -1;
		NodoArbol<E> nodoControl = controlNodo(e);
		NodoArbol<E> nPadre = null;

		// Si el arbol no tiene elementos debemos de devolver -1
		if (size == 0) {
			return profundidad;
		}
		/*
		 * Controlamos que el nodo forma parte del arbol, eso es porque el nodoControl
		 * que se nos devuelve, es el nodo que lo contiene (==0), si no pues no entra en
		 * if
		 */
		if (comparar(nodoControl.getElemento(), e) == 0) {

			// Cogemos el nodo padre del nodo que contiene el elemento e
			nPadre = nodoControl.getPadre();
			profundidad++;// Aumentamos la profundidad

			// Seguimos ascendiendo hasta que el nodo padre sea null
			while (nPadre != null) {
				nPadre = nPadre.getPadre();
				profundidad++;
			}
		}
		return profundidad;
	}

	/**
	 * M�todo que nos devuelve la altura de un elemento, ya que saca el nodo en el
	 * que se encuentra, para recorrer iterativamente hasta encontrar el nodo
	 * 
	 * @param e, elemento del cual vamos a calcular la altura
	 * @return int altura
	 */
	public int altura(E e) {
		// Miramos que el arbol tenga al menos elementos o que contenga el nodo quee se
		// le pasa
		Object eAux = e;

		// Cpontrolamos que los datos que se nos pasan son validos
		if (e == null) {
			return 0;
		}

		if (size == 0 || !contains(e)) {
			return -1;
		}

		// Cogemos el nodo donde se encuentra el elemento
		NodoArbol<E> nodoControl = controlNodo((E) eAux);

		// dependiendo del nodo vamos recorriendo en altura
		if (nodoControl.getNodoDerecha() == null && nodoControl.getNodoIzquierda() == null) {
			return 0 + Math.max(altura(null), altura(null));
		}

		if (nodoControl.getNodoIzquierda() == null) {
			return 1 + Math.max(altura(null), altura(nodoControl.getNodoDerecha().getElemento()));
		}
		if (nodoControl.getNodoDerecha() == null) {
			return 1 + Math.max(altura(nodoControl.getNodoIzquierda().getElemento()), altura(null));
		}

		// Controlamos de manera iterativa el resultado que teneoms que devolver
		return 1 + Math.max(altura(nodoControl.getNodoIzquierda().getElemento()),
				altura(nodoControl.getNodoDerecha().getElemento()));
	}

	/**
	 * M�todo que nos devuelve el mayor de los nodos, a partir de un nodo que le
	 * pasemos
	 * 
	 * @param inicio, es el nodo de control a partir del cual vamos a tratar
	 *        calcular el elemento mayor
	 * @return el mayor de los nodos dentro de la rama que busca
	 */
	public NodoArbol<E> mayorNodo(NodoArbol<E> inicio) {

		NodoArbol<E> nodoMayor = inicio;

		while (nodoMayor.getNodoDerecha() != null) {
			nodoMayor = nodoMayor.getNodoDerecha();
		}
		return nodoMayor;
	}

	/**
	 * M�todo que nos devuelve el menor de los nodos a partir de uno de los nodos
	 * que le pasamos como par�metro
	 * 
	 * @param inicio nodo de control a partir del cual busca
	 * @return el menor de los nodos dentro de la rama que busca
	 */
	public NodoArbol<E> menorNodo(NodoArbol<E> inicio) {

		NodoArbol<E> nodoMenor = inicio;

		while (nodoMenor.getNodoIzquierda() != null)
			nodoMenor = nodoMenor.getNodoIzquierda();

		return nodoMenor;
	}

	/**
	 * M�todo contains Sirve para ver si el Objeto que se nos pasa esta contenido
	 * dentro del arbol
	 * 
	 * @param o objeto que queremos encontrar en la estructura
	 * @return booleano con el contenido de la busqueda
	 */
	@Override
	public boolean contains(Object o) {
		E e = (E) o;
		NodoArbol<E> nodoControl = controlNodo(e);

		if (comparar(nodoControl.getElemento(), e) == 0) {
			return true;
		}

		return false;
	}

	/**
	 * M�TODOS QUE A�ADIMOS PARA LA PR�CTICA 11 19/05/2019
	 */

	/**
	 * M�todo getComparador, este m�todo nos devuelve el comparador de la estructura
	 * de los �rboles de b�squeda binaria
	 * 
	 * @return Comparador
	 */
	public Comparator<? super E> getComparador() {
		return this.comparador;
	}

	/**
	 * M�todo que nos devuelve una lista con cada uno de los elementos del arbol, de
	 * menor a mayor
	 * 
	 * @return Lista con el contenido del arbol
	 */
	public List<E> getListaInOrden() {
		// Declaramos las variables
		List<E> listaInOrden = new ArrayList<E>();

		// A�adimos los elementos a la lista por el m�todo inOrden
		listaInOrden = rellenarIterador(nodoRaiz, listaInOrden);

		return listaInOrden;
	}

	/**
	 * M�todo que nos devuelve el nodo raiz del la estuctura
	 * 
	 * @return NodoArbol que es la raiz
	 */
	public NodoArbol<E> getNodoRaiz() {
		return this.nodoRaiz;
	}
}
