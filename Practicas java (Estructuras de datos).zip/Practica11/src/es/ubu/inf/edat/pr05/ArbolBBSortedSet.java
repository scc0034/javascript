package es.ubu.inf.edat.pr05;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;

/**
 * Clase {@link ArbolBBSortedSet}
 * 
 * @author Samuel Casal Cantero
 *
 */
public class ArbolBBSortedSet<E> extends ArbolBB<E> implements SortedSet<E> {

	// Declaramos los atributos de la clase ABBSorted
	private NodoArbol<E> nodoRaiz = null;
	private Comparator<E> comparador = null;

	// Constructor vacio
	public ArbolBBSortedSet() {
		super();
		this.nodoRaiz = getNodoRaiz();
	}

	// Constructor con comparador
	public ArbolBBSortedSet(Comparator<? super E> comparador) {
		super(comparador);
		this.nodoRaiz = getNodoRaiz();
		this.comparador = (Comparator<E>) getComparador();
	}

	// Constructor con coleccion de datos
	public ArbolBBSortedSet(Collection<E> conjuntoElementos) {
		super(conjuntoElementos);
		this.nodoRaiz = getNodoRaiz();
	}

	// Constructor para comparador + datos
	public ArbolBBSortedSet(Collection<E> conjuntoElementos, Comparator<? super E> comparador) {
		super(conjuntoElementos, comparador);
		this.nodoRaiz = getNodoRaiz();
		this.comparador = (Comparator<E>) getComparador();
	}

	/**
	 * M�TODOS QUE TENEMOS QUE SOBREESCRIBIR
	 */

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * M�todo que nos devuelve el comparador de la clase ArborSortedSet
	 * 
	 * @return Comparator comparador de los objetos de la estructura arborea
	 */
	public Comparator comparator() {
		return getComparador();
	}

	/**
	 * M�todo subset, nos devuelve una vista con los elementos de la estructura
	 * arb�rea
	 * 
	 * @param fromElement elemento desde el que vamos a hacer el subset
	 * @param toElement   elemento final desde el que se corta la siblista
	 * 
	 * @return subset que contiene los elementos de la sublista
	 */
	@SuppressWarnings("unchecked")
	@Override
	public SortedSet<E> subSet(Object fromElement, Object toElement) {
		// Controlamos los elementos que se nos pasan
		// Miramos que los elementos no sean null
		if (fromElement == null || toElement == null) {
			// Lanzamos la excepcion de que no podemos tener elementos nulos
			throw new NullPointerException("No se permiten elementos nulos.");
		}
		// Miramos que los elementos esten dentro del arbol
		if (!contains(fromElement) || !contains(toElement)) {
			// Lanzamos la excepcion de que alguno de los elemenos no esta en la estructura
			// del arbol
			throw new IllegalArgumentException("Elementos que no se encuentran en el arbol");
		}
		// Controlamos que el elemenots inicio es menor que final
		if (comparar((E) fromElement, (E) toElement) > 0) {
			throw new IllegalArgumentException("Inicio mayor que final.");
		}

		// Cogemos la lista que contiene todos los elementos del arbol
		ArrayList<E> listaArbol = new ArrayList<E>(getListaInOrden());

		return new ArbolBBSortedSet<E>(
				listaArbol.subList(listaArbol.indexOf(fromElement), listaArbol.indexOf(toElement)));
	}

	/**
	 * M�todo headSet, este m�todo nos devuelve una lista con los elemenots que son
	 * menores que el elemento que pasamos como par�metro, todos los valores que
	 * devuelve tienen que estar contenidos en la estructura del arbol
	 * 
	 * @param toElement, elemento m�s gran de todos los que vamos a devolver
	 * 
	 * @return lista que contiene los elementos menores que toElement
	 */
	@Override
	public SortedSet<E> headSet(Object toElement) {
		if (toElement == null) {
			// Lanzamos la excepcion de que no podemos tener elementos nulos
			throw new NullPointerException("No se permiten elementos nulos.");
		}
		// Miramos que los elementos esten dentro del arbol
		if (!contains(toElement)) {
			// Lanzamos la excepcion de que alguno de los elemenos no esta en la estructura
			// del arbol
			throw new IllegalArgumentException("Elemento que no se encuentra en el arbol.");
		}

		// Cogemos el primero de los elementos de la lista
		// Cogemos la lista que contiene todos los elementos del arbol
		ArrayList<E> listaArbol = new ArrayList<E>(getListaInOrden());
		// Declaramos la lista que vamos a insertar en el arbolBBSorted
		Collection<E> listaInsertar = new ArrayList<E>();

		// Controlamos que elementos son menores que el que se nos dan
		for (E e : listaArbol) {
			// Cogemos solo los elementos menores de toElement
			if (comparar(e, (E) toElement) < 0) {
				listaInsertar.add(e);
			}
		}

		return new ArbolBBSortedSet<E>(listaInsertar);
	}

	/**
	 * M�todo tailSet, devuelve una lista que contiene los elementos mayores e igual
	 * que uno de los elemetos que pasamos como par�metro de entrada
	 * 
	 * @param fromElement desde el que queremos los mayores
	 * @return lista que contiene los elementos que queremos
	 */
	@Override
	public SortedSet<E> tailSet(Object fromElement) {
		// Cogemos el primero de los elementos de la lista
		// Cogemos la lista que contiene todos los elementos del arbol
		ArrayList<E> listaArbol = new ArrayList<E>(getListaInOrden());

		// De esta manera tambien tenemos las excepciones del metodo headset
		Collection<E> listaQuitar = headSet(fromElement);
		// Cogemos los elementos que nos interesan para la lista
		listaArbol.removeAll(listaQuitar);

		return new ArbolBBSortedSet<E>(listaArbol);
	}

	/**
	 * M�todo first, devuelve el elemento m�s peque�o de la estructura
	 * 
	 * @return Object primero de los elementos, el menor de todos
	 */
	@Override
	public E first() {
		this.nodoRaiz = super.getNodoRaiz();
		return super.menorNodo(nodoRaiz).getElemento();
	}

	/**
	 * M�todo last, devuelve el elemento m�s grande de la estructura
	 * 
	 * @return Object primero de los elementos, el mayor de todos
	 */
	@Override
	public E last() {
		this.nodoRaiz = super.getNodoRaiz();
		return super.mayorNodo(nodoRaiz).getElemento();
	}

	/**
	 * M�todo de reconstruir el arbol, todo a partir de dos listas qeu pasamos como
	 * par�metros por una parte tenemos una que contiene el recorrido en inorden y
	 * la otra en preorden.
	 * 
	 * @param preorden lista preorden
	 * @param inorden  lista inorden
	 * @return {@link NodoArbol} tenemos que devolver nodos del arbol, de tal manera
	 *         que el construyeArbol es capad de cogerlos como nodos, si no de los
	 *         elementos ten�amos que hacer la conversion a nodoarbol y de ahi coger
	 *         los nodos que cuelgan de cada uno. Por lo que mucho mejor con el
	 *         NodoArbol
	 */
	public NodoArbol<E> reconstruyeArbol(List<E> preorden, List<E> inorden) {
		// Controlamos que las listas tengan elementos
		if (inorden.size() <= 0 || preorden.size() <= 0) {
			return null;
		} else {
			int i = 0;
			// Bucle que recorre cada uno de los elementos de inorden comparando con el
			// preorden 0
			while (comparar(inorden.get(i), preorden.get(0)) != 0) {
				i++;
			}
			// Llamada recursiva que llama al construye arbol
			return construyeArbol(preorden.get(0), reconstruyeArbol(preorden.subList(1, i + 1), inorden.subList(0, i)),
					reconstruyeArbol(preorden.subList(i + 1, preorden.size()), inorden.subList(i + 1, inorden.size())) );
		}
	}

	/**
	 * M�todo construye, se encarga de construir un arbol a partir de los nodos que
	 * se pasar del reconstruye arbol
	 * 
	 * @param e elemento con el que vamos a crear el nodo, es decir el valor
	 * @param nIzq nodo de la izquierda
	 * @param nDer nodo de la derecha
	 * @return nodoArbol, en ultima instancia nos devuelve el nodo raiz
	 */
	public NodoArbol<E> construyeArbol(E e, NodoArbol<E> nIzq, NodoArbol<E> nDer) {
		// Cada vez que vamos a reconstruir un nodo es porque vamos a crearlo para el
		// arbol
		size++;

		// Creamos el nodo con el nuevo constructor
		NodoArbol<E> nodo = new NodoArbol<E>(e, nDer, nIzq, null);

		// En mi estructura tenemos tambien referencias a los nodos padre
		if (nIzq != null) {
			nodo.getNodoIzquierda().setPadre(nodo);
		}
		if (nDer != null) {
			nodo.getNodoDerecha().setPadre(nodo);
		}

		// Cambiamos el nodo raiz para que nos funcione el iterador
		// En la ultima de las interaciones de este procedimiento, el nodo raiz es la
		// raiz
		this.nodoRaiz = nodo;
		super.nodoRaiz = nodo;

		// Devolvemos el nodo que usamos en esta parte
		return nodo;
	}
}
