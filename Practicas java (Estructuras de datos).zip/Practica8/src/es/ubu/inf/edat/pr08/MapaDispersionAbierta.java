package es.ubu.inf.edat.pr08;

//Librerias
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Clase {@link MapaDispersionAbierta} Mapa personasl como se nos manda en la
 * pr�ctica 8 de EDAT
 * 
 * @author Samuel Casal Cantero
 * @version 16/04/2019
 * @param <K> key
 * @param <V> value
 */
public class MapaDispersionAbierta<K, V> extends AbstractMap<K, V> {

	/**
	 * Clase {@link EntradaMultiple} CUBETA Son las encargadas de contener las
	 * listas de las parejas
	 * 
	 * @version 16/04/2019
	 * @param <K> key
	 * @param <V> value
	 */
	private class EntradaMultiple<K, V> {
		// Atributos
		List<EntradaPlana<K, V>> listaParejas;
		private int tamanoCubeta = 0;

		// Contructor
		public EntradaMultiple(int tamanoCubeta) {
			this.tamanoCubeta = tamanoCubeta;
			this.listaParejas = new ArrayList<EntradaPlana<K, V>>(tamanoCubeta);
		}

		/**
		 * M�todo para insertar parejas de clave valor dentro de la cubeta
		 * 
		 * @param key
		 * @param valor
		 * @return valor V
		 */
		public V insertaPareja(K key, V valor) {
			// Variables
			boolean isKey = false;// Controla si la clave esta dentro del mapa o no
			int posicion = 0;// Posicion en la que se encuentra la clave en el caso de coincidir
			// Recorremos la cubeta para ver si la clave que se nos pasa coincide con alguna
			for (int i = 0; i < listaParejas.size(); i++) {
				// Cogemos cada pareja de la cubeta
				EntradaPlana<K, V> pareja = listaParejas.get(i);

				// Miramos si las claves son iguales
				if (pareja.getKey().hashCode() == key.hashCode()) {
					isKey = true;// Acticamos la bandera que controla que la clave se repite
					posicion = i;// Posicion en la que se encuentra la clave en el caso de coincidir
				}
			}

			// En el caso de que la clave no este se a�ade normal a la lista
			if (isKey == false) {
				EntradaPlana<K, V> parejaNueva = new EntradaPlana<K, V>(key, valor);
				listaParejas.add(parejaNueva);
				// En el caso de que a�adimos se nos de un desborde tenemos que redimensionar
				// todo
				if (listaParejas.size() > tamanoCubeta) {
					redimensionar();
				}
				return null;// Devolvemos el null que es lo que hay cuando no tenemos nada
			} else {
				// Cogemos el valor antiguo para devolverlo y lo cambiamos
				V valorAntiguo = listaParejas.get(posicion).getValue();
				listaParejas.get(posicion).setValue(valor);
				return valorAntiguo;
			}
		}

		// M�todo get que nos devuelve la lista con las entradas multiples
		public List<EntradaPlana<K, V>> getListaEntradaMultiple() {
			return listaParejas;
		}

		/**
		 * M�todo que nos devuelve el valor de una clave
		 * 
		 * @param key
		 * @return V
		 * @throws NullPointerException
		 */
		public V get(Object clave) {
			for (int i = 0; i < listaParejas.size(); i++) {
				if (clave == listaParejas.get(i).getKey()) {
					return listaParejas.get(i).getValue();
				}
			}
			// En el caso de que se nos de una clave que no este salta Exception
			throw new NullPointerException();
		}

		/**
		 * M�todo que nos devuelve el objeto EntradaPlana a partir de una clave
		 * 
		 * @param key
		 * @return EntradaPlana
		 * @throws NullPointerException
		 */
		public EntradaPlana<K, V> getPar(Object key) {
			// Buscamos que coincide la clave dentro de la cubeta
			for (int i = 0; i < listaParejas.size(); i++) {
				if (key == listaParejas.get(i).getKey()) {
					return listaParejas.get(i);
				}
			}
			// En el caso de que se nos de una clave que no este salta Exception
			throw new NullPointerException();
		}
	}

	/**
	 * Clase {@link EntradaPlana} Es el par de elementos clave valor
	 * 
	 * @author Samuel Casal Cantero
	 * @version 16/04/2019
	 * @param <K> key
	 * @param <V> value
	 */
	private class EntradaPlana<K, V> extends SimpleEntry<K, V> {

		/**
		 * Constructor de la clase EntradaPlana
		 * 
		 * @param <K> key
		 * @param <V> value
		 */
		public EntradaPlana(K key, V value) {
			super(key, value);
		}
	}

	// Atributos de la clase MapaDispersionAbierta
	private int tamanoCubeta = 3;
	private int numeroCubetas = 16;
	private int numeroEntradas = 0;
	private List<EntradaMultiple<K, V>> tabla;
	private final float aumento = (float) 1.5;

	/**
	 * Constructor de la clase MapaDispersionAbierta
	 * 
	 * @param tamanoCubeta numero del tama�o de la cubeta
	 * @param numeroCubeta numero de cubetas
	 * @throws IllegalArgumentException salta fallo por malos argumentos
	 */
	public MapaDispersionAbierta(int tamanoCubeta, int numeroCubeta) {
		// Controlamos que los parametros que se nos pasan son validos
		if (tamanoCubeta <= 0 || numeroCubeta <= 0) {
			throw new IllegalArgumentException("Parametros que se pasan no son v�lidos");
		}
		this.tamanoCubeta = tamanoCubeta;
		this.numeroCubetas = numeroCubeta;
		this.tabla = new ArrayList<EntradaMultiple<K, V>>(numeroCubeta);
		// Vaciamos la tabla
		clear();
	}

	/**
	 * Constructor que no recibe par�metros, entonces coge los que tiene por defecto
	 */
	public MapaDispersionAbierta() {
		this.tabla = new ArrayList<EntradaMultiple<K, V>>(this.numeroCubetas);
		clear();
	}

	@Override
	/**
	 * M�todo que limpia el mapa
	 */
	public void clear() {
		for (int i = 0; i < numeroCubetas; i++) {
			tabla.add(i, new EntradaMultiple<K, V>(tamanoCubeta));
		}
		numeroEntradas = 0;
	}

	/**
	 * M�todo que nos devuelve el n�mero de cubetas del mapa
	 * 
	 * @return int numeroCubetas
	 */
	public int getNumeroCubetas() {
		return numeroCubetas;
	}

	@Override
	/**
	 * M�todo que nos devuelve el numero de entradas del mapa
	 * 
	 * @return int numeroEntradas del mapa
	 */
	public int size() {
		return numeroEntradas;
	}

	@Override
	/**
	 * M�todo que controla si el mapa esta vacio o no
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	/**
	 * M�todo que sirve para eliminar una EntradaPlana de una de las cubetas que
	 * contienen la clave que se pasa como paramametro
	 * 
	 * @return V valor eliminado
	 */
	public V remove(Object key) {
		// Cogemos el numero de la cubeta que toca
		int numeroCubetaQueToca = key.hashCode() % numeroCubetas;
		// Cogemos la cubeta del mapa
		EntradaMultiple<K, V> cubeta = tabla.get(numeroCubetaQueToca);
		// Cogemos el valor de la cubeta que tiene la clave
		V valor = cubeta.get(key);
		// Cogemos el objeto plano que contiene la pareja
		List<EntradaPlana<K, V>> listaCubeta = cubeta.getListaEntradaMultiple();
		listaCubeta.remove(cubeta.getPar(key));
		numeroEntradas--;// Reducimos el tama�o del mapa
		return valor;
	}

	@Override
	/**
	 * M�todo get que nbos devuelve el valor a partir de la clave En el caso de que
	 * hagamos el get de un valor que no tiene el mapa va a saltar la exception del
	 * get de las cubetas que en este caso es el get de la clase EntradaMultiple
	 * 
	 * @param Object key
	 * @return v valor
	 */
	public V get(Object key) {

		int numeroCubetaQueToca = key.hashCode() % numeroCubetas;

		// Recogemos la cubeta que toca para mirar si es nula o no y trabajar con ella
		EntradaMultiple<K, V> cubeta = tabla.get(numeroCubetaQueToca);

		// llamamos al metodo de la cubeta que tiene el get
		return cubeta.get(key);
	}

	@Override
	/**
	 * M�todo que nos devuelve un conjunto con todos los valores del mapa
	 * 
	 * @return set con todos los valores del mapa
	 */
	public Set<V> values() {
		Set<V> conjuntoValores = new HashSet<V>();

		// En el caso de que el este vacio devolvemos el set vacio
		if (isEmpty()) {
			return conjuntoValores;
		}
		// Recorremos todos los elementos del mapa
		for (int i = 0; i < numeroCubetas; i++) {
			EntradaMultiple<K, V> cubeta = tabla.get(i);
			List<EntradaPlana<K, V>> listaCubeta = cubeta.getListaEntradaMultiple();
			for (int j = 0; j < listaCubeta.size(); j++) {
				V value = (V) listaCubeta.get(j).getValue();
				if (value != null) {
					conjuntoValores.add(value);
				}
			}
		}
		return conjuntoValores;
	}

	@Override
	/**
	 * M�todo keySet que nos devuelve un conjunto de las claves del mapa
	 * 
	 * @return keySet con las claves del mapa, en el caso de que se encuentre vacio
	 *         el valor que va a devolver es unconjunto vacio
	 */
	public Set<K> keySet() {
		Set<K> conjuntoClaves = new HashSet<K>();

		// En el caso de que el este vacio devolvemos el set vacio
		if (isEmpty()) {
			return conjuntoClaves;
		}

		// Recorremos las cubetas del mapa, y de cada cubeta la lista, donde sacamos las
		// keys
		for (int i = 0; i < numeroCubetas; i++) {
			EntradaMultiple<K, V> cubeta = tabla.get(i);
			List<EntradaPlana<K, V>> listaCubeta = cubeta.getListaEntradaMultiple();
			for (int j = 0; j < listaCubeta.size(); j++) {
				K key = (K) listaCubeta.get(j).getKey();
				if (key != null) {
					conjuntoClaves.add(key);
				}
			}
		}
		return conjuntoClaves;
	}

	@Override
	/**
	 * M�todo entrySet que nos devuelve el conjutno con las parejas de valores y
	 * claves
	 * 
	 * @return entrySet
	 */
	public Set<Entry<K, V>> entrySet() {
		Set<Entry<K, V>> conjuntoParejas = new HashSet<Entry<K, V>>();
		if (isEmpty()) {
			return conjuntoParejas;
		}
		// De cada cubeta cogemos las parejas
		for (EntradaMultiple<K, V> cubeta : tabla) {
			conjuntoParejas.addAll(cubeta.getListaEntradaMultiple());
		}
		return conjuntoParejas;
	}

	/**
	 * M�todo para redimensionar el mapa, en el caso de que una de las cubetas
	 * desborde de tama�o o que nos quedemos sin cubetas libres en todo el mapa
	 * 
	 * Lo que hace es aumentar el tama�o de las cubetas en el aumento que tengamos
	 * declarado Cogemos el entrySet del mapa que tenemos, eliminamos el mapa,
	 * redimensionamos y a�adimos el entrySet que teniamos, cada una en su nueva
	 * cubeta que corresponda
	 */
	public void redimensionar() {
		// Calculamos el nuevo numero de cubetas
		int nuevoNumeroCubetas = (int) (aumento * numeroCubetas);

		// Cogemos todos los elementos que tiene el mapa
		Set<Entry<K, V>> conjuntoTotal = entrySet();
		// Cambiamos el valos de numeroCubetas por el nuevo que hemos calculado
		this.numeroCubetas = nuevoNumeroCubetas;

		// Cambiamos el tama�o de la tabla para que coincida con el numero de cubetas
		// nuevo
		this.tabla = new ArrayList<EntradaMultiple<K, V>>(nuevoNumeroCubetas);
		// La limpiamos de todo contenido
		clear();

		// Para cada elemento del entrySet lo metemos donde corresponda
		for (Entry<K, V> pareja : conjuntoTotal) {
			put(pareja.getKey(), pareja.getValue());
		}

		// Se produce un desbordamiento de una unidad al hacer el put anterior por lo
		// que quitamos una
		numeroEntradas--;
	}

	@Override
	/**
	 * M�todo put, que sirve para introducir elementos al mapa
	 * 
	 * @param K key
	 * @param V value
	 * @return V valor que hemos metido o el antiguo
	 */
	public V put(K key, V value) {

		// Los valores que se pasan como par�metros no pueden ser nulos
		if (key == null || value == null) {
			throw new NullPointerException();
		}
		// Calculamos la cubeta que le toca a la key que se nos pasa
		int numeroCubetaQueToca = key.hashCode() % numeroCubetas;

		// Recogemos la cubeta que toca para mirar si es nula o no y trabajar con ella
		EntradaMultiple<K, V> cubeta = tabla.get(numeroCubetaQueToca);

		V valorInsertado = (V) cubeta.insertaPareja(key, value);

		if (valorInsertado == null) {
			// Aumentamos el numero de objetos dentro de nuestro mapa
			numeroEntradas++;
		}
		return valorInsertado;
	}

	@Override
	/**
	 * M�todo toSting que sirve para convertir el mapa a cadena, para luego podemos
	 * mostrar los datos
	 */
	public String toString() {
		String cadena = new String();
		int contadorCubeta = 0;
		int contadorPareja = 0;

		for (EntradaMultiple<K, V> cubeta : tabla) {
			cadena += "Cubeta --> " + contadorCubeta + "\n";
			contadorCubeta++;
			for (EntradaPlana<K, V> pareja : cubeta.getListaEntradaMultiple()) {
				cadena += "\tElemento --> " + contadorPareja + "\n";
				contadorPareja++;
				cadena += "\t\tKey:" + pareja.getKey() + "\n";
				cadena += "\t\tValue:" + pareja.getValue() + "\n";
			}
			contadorPareja = 0;
		}
		return cadena;

	}
}
