package es.ubu.inf.edat.pr08;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import es.ubu.inf.edat.pr08.Personas.Alumno;
import es.ubu.inf.edat.pr08.Personas.GeneradorPersonas;
import es.ubu.inf.edat.pr08.Personas.Persona;

public class TestMapaDispersionAbiertaPersonas {

	Persona[] personas = GeneradorPersonas.soloAlumnos();
	MapaDispersionAbierta<String, Persona> mapa;

	@Before
	public void setUp() throws Exception {
		mapa = new MapaDispersionAbierta<String, Persona>(3, 5);
	}

	@After
	public void tearDown() throws Exception {
		mapa.clear();
	}

	@Test
	public void testPutConSinEspacioPersonas() {

		for (int i = 0; i < personas.length; i++) {
			String dni = personas[i].getNif();
			assertEquals(null, mapa.put(dni, personas[i]));
		}

		assertEquals(personas.length, mapa.size());
		//Tenemos que redimensionar una vez porque los dnis llenan algunas cubetas
		assertEquals(7,mapa.getNumeroCubetas());

	}
	
	@Test
	public void testPut_SobreescribirPersona() {
		
		testPutConSinEspacioPersonas();
		Persona personaSobreescribir = new Alumno("apellidos", "nombre", personas[0].getNif() , "Mujer", 3002);
		assertEquals(personas[0], mapa.put(personas[0].getNif(),personaSobreescribir));
		
		assertEquals(personaSobreescribir,mapa.get(personas[0].getNif()));	
		assertEquals(personas.length, mapa.size());
		assertEquals(7,mapa.getNumeroCubetas());
		
	}
	
	@Test
	public void testRemove() {
		
		testPutConSinEspacioPersonas();
		String dni = personas[0].getNif();
		assertEquals(personas[0], mapa.remove(dni));
		assertFalse(mapa.keySet().contains(dni));

		assertEquals(personas.length-1, mapa.size());
		assertEquals(7, mapa.getNumeroCubetas());
		
	}
	
	@Test
	public void mostrarMapa() {
		testPutConSinEspacioPersonas();
		System.out.println(mapa.toString());
	}

}
